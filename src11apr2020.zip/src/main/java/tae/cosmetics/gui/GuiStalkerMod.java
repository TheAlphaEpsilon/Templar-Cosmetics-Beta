package tae.cosmetics.gui;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.imageio.ImageIO;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.network.play.client.CPacketTabComplete;
import net.minecraft.util.ResourceLocation;
import tae.cosmetics.gui.util.GuiPlayerOptionsButton;
import tae.cosmetics.gui.util.ScrollBar;
import tae.cosmetics.mods.UnicodeKeyboard;
import tae.cosmetics.mods.UnicodeKeyboard.TextType;
import tae.cosmetics.util.MojangGetter;
import tae.cosmetics.util.PlayerAlert;
import tae.cosmetics.util.PlayerAlert.PlayerData;

public class GuiStalkerMod extends GuiScreen {
	
	private static final ResourceLocation STALKER_MOD_GUI = new ResourceLocation("taecosmetics","textures/gui/playeralert.png");
	private static final ResourceLocation DEFAULT_SKIN = new ResourceLocation("textures/entity/steve.png");


	
	
    private static final String sign = UnicodeKeyboard.toUnicode("TEMPLAR", TextType.SMALL);
	
	private static HashMap<String, PlayerTextureData> resourcemap;
	
	private static GuiStalkerMod INSTANCE = null;
	
	private int xOffset = -20;
	private int yOffset = -40;
	
	private static final int moduleheight = 58;
	
    //number of rows of modules to load
    private int rows;
    
    private GuiButton addplayerbutton;
    private GuiButton settingsbutton;
    
    private ScrollBar scroll;
    
    private GuiPlayerOptionsButton[] playeroptionbuttons;
    
    private GuiTextField nameField;
    private boolean firstText;
    
    private String errorMessage;
    private int errorTick = -1;
    
    private String message;
    private int messageTick = -1;
    
    private Color taeTextColor = new Color(0, 255, 0, 255);
    
	private GuiStalkerMod() {
		super();
		resourcemap = new HashMap<String, PlayerTextureData>();
        addplayerbutton = new GuiButton(0, 0, 0, 60, 20, "Add Player");
        settingsbutton = new GuiButton(1, 0, 0, 190, 20, "Settings");
       
        playeroptionbuttons = new GuiPlayerOptionsButton[6];
        
        scroll = new ScrollBar(0, 0, 116);
        
		INSTANCE = this;
	}
	
	public static GuiStalkerMod instance() {
		if(INSTANCE == null) {
			return new GuiStalkerMod();
		} else {
			return INSTANCE;
		}
	}
	
	@Override
	public void initGui() {
		super.initGui();
				
		new Thread(() -> {
			
			updateResourceMap();
		
		}).start();
		
		int j = height/2 + yOffset;
		
		for(int i = 0; i < playeroptionbuttons.length; i++) {
			playeroptionbuttons[i] = new GuiPlayerOptionsButton(2+i, 0, 0, 13, 13, null, null, j + 97, j - 50);
		}	
			
		Keyboard.enableRepeatEvents(true);
		
		if(buttonList.isEmpty()) {
			buttonList.add(addplayerbutton);
			buttonList.add(settingsbutton);
		}
		
		//init namefield
        if(nameField == null ) {        	
        	
        	this.nameField = new GuiTextField(0, fontRenderer, 0, 0, 103, 12);
        	this.nameField.setTextColor(-1);
        	this.nameField.setDisabledTextColour(-1);
        	this.nameField.setEnableBackgroundDrawing(false);
        	this.nameField.setMaxStringLength(16);
        }
        
        this.nameField.setText("ADD PLAYER");
        firstText = true;
        
        errorTick = -1;
        messageTick = -1;
	}
	
	@Override
	public void onGuiClosed() {
		super.onGuiClosed();
		Keyboard.enableRepeatEvents(false);
		nameField.setFocused(false);
	}
	
	@Override
	protected void actionPerformed(GuiButton button) throws IOException {
		if(button == addplayerbutton) {
			String name = nameField.getText();
			if(name.isEmpty()) {
				errorMessage = "No name!";
				errorTick = 250;
			} else {
								
				if(PlayerAlert.alertExists(name)) {
					
					errorMessage = "Already exists!";
					errorTick = 250;
							
				} else {
				
					String truename = PlayerAlert.addName(name);
					if(truename == null) {
						errorMessage = "Doesn't exist!";
						errorTick = 250;
					} else {
						message = "Added!";
						messageTick = 250;
						nameField.setText("");
						new Thread(() -> {
						
							updateResourceMap();
							
						}).start();
						
						mc.getConnection().sendPacket(new CPacketTabComplete(name, null, false));
					}
					
				}
			}
			
		} else if (button == settingsbutton) {
			mc.addScheduledTask(() -> {
				//mc.displayGuiScreen(null);
				mc.displayGuiScreen(new GuiStalkerModGlobalOptions());
			});
		} else if (button instanceof GuiPlayerOptionsButton) {
			mc.addScheduledTask(() -> {
				//mc.displayGuiScreen(null);
				mc.displayGuiScreen(new GuiStalkerModPlayerOptions(((GuiPlayerOptionsButton) button).getUUID(), ((GuiPlayerOptionsButton) button).playerTexture));
			});
		}
	}
	
	@Override
	protected void keyTyped(char typedChar, int keyCode) throws IOException {
		if (this.nameField.textboxKeyTyped(typedChar, keyCode)) {
        }
        else {
            super.keyTyped(typedChar, keyCode);
        }
    }
	
	@Override
	protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
		
		super.mouseClicked(mouseX, mouseY, mouseButton);
        
		for(int i = 0; i < playeroptionbuttons.length; i++) {
			GuiPlayerOptionsButton button = playeroptionbuttons[i];
			if(button.mousePressed(mc, mouseX, mouseY)) {
				this.actionPerformed(button);
			}
		}
		
		if(this.nameField.mouseClicked(mouseX, mouseY, mouseButton) && firstText) {
			firstText = false;
			nameField.setText("");
		}
        
    }
	
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
			
		updateTextColor();
		
		int i = width/2 + xOffset;
		int j = height/2 + yOffset;
		
		addplayerbutton.x = i - 96;
		addplayerbutton.y = j - 43;
		
		settingsbutton.x = i - 65;
		settingsbutton.y = j + 103;
		
		nameField.x = i - 23;
		nameField.y = j - 36;
		
		scroll.x = i + 141;
		scroll.y = j - 18;
        		
		GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.disableLighting();
		GlStateManager.enableAlpha();
		GlStateManager.enableBlend();
				
		//draw background sides
		mc.getTextureManager().bindTexture(STALKER_MOD_GUI);
		this.drawTexturedModalRect(i - 100, j - 50, 0, 0, 7, 178);
		this.drawTexturedModalRect(i + 137, j - 50, 115, 178, 24, 60);
		this.drawTexturedModalRect(i + 137, j + 10, 163, 178, 24, 59);
		this.drawTexturedModalRect(i + 137, j + 68, 139, 178, 24, 60);
		
		//draw scrollbar
		scroll.setDisabled(!this.needsScrollBars());
		scroll.draw(mouseX, mouseY);
		
		Set<String> keyset = resourcemap.keySet();
		rows = (int) Math.ceil(keyset.size() / 2.0D);
		int scrolloffset = (rows -2) * ((int) (scroll.getScroll() * moduleheight));
		
		//draw modules
		
		for(int x = 0; x < 2; x++) {
					//+58
			//top row
			this.drawTexturedModalRect(i - 93 + (x*115), j - 19, 0 , 178 + scrolloffset % moduleheight, 115, moduleheight - (scrolloffset % moduleheight));
			//middle row
			this.drawTexturedModalRect(i - 93 + (x*115), j + 39 - (scrolloffset % moduleheight), 0, 178, 115, 58);
			//bottom row
			this.drawTexturedModalRect(i - 93 + (x*115), j + 97 - (scrolloffset % moduleheight), 0, 178, 115, (scrolloffset % moduleheight));
						
		}
		
		//draw skins and data
				
		//used to get what data to render
		int toprow = scrolloffset / moduleheight;
					
		List<String> keys = PlayerAlert.getOrderedUUIDFromName();
				
		keys.sort(new Comparator<String>() {

			HashMap<String, PlayerData> dataMap = PlayerAlert.dataCopy();
			
			@Override
			public int compare(String o1, String o2) {
				
				boolean o1InGame = dataMap.get(o1).getInGame();
				boolean o2InGame = dataMap.get(o2).getInGame();
				
				boolean o1InQueue = dataMap.get(o1).queuePos() > 0 ? true : false;
				boolean o2InQueue = dataMap.get(o2).queuePos() > 0 ? true : false;
				
				int o1Comp = 0;
				if(!o1InGame) {
					o1Comp = 2;
				}
				if(o1InQueue) {
					o1Comp = 1;
				}
				
				int o2Comp = 0;
				if(!o2InGame) {
					o2Comp = 2;
				}
				if(o2InQueue) {
					o2Comp = 2;
				}
				
				if(o1Comp != o2Comp) {
					return o1Comp - o2Comp;
				} else {
					return dataMap.get(o1).getOldName().toLowerCase().compareTo(dataMap.get(o2).getOldName().toLowerCase());
				}
				
			}

			
			
		});
		
		if(resourcemap.size() == keys.size()) {
			for(int y = 0; y < 3; y++) {
				for(int x = 0; x < 2; x++) {			
					int keypos = (toprow * 2) + (y * 2) + x;
										
					if(keypos < keys.size()) {
					
						String thisUUID = keys.get(keypos);
						
						PlayerTextureData data = resourcemap.get(thisUUID);
						PlayerData playerdata = PlayerAlert.dataCopy().get(thisUUID);
						
						if(data.location == null) {
							
							DynamicTexture skinTexture = new DynamicTexture(data.image);
							data.location = mc.getTextureManager().getDynamicTextureLocation(thisUUID, skinTexture);
							
						}
						
						GuiPlayerOptionsButton thisButton = playeroptionbuttons[(y*2) + x];
						thisButton.setUUID(thisUUID);
						thisButton.playerTexture = data;
						thisButton.visible = false;
											
						int yoffset = (int) (j + (y * 58) - ((float)scrolloffset % moduleheight));
						
						//show and position buttons
						
						if(yoffset > j - 50 && yoffset + 5 < j + 97) {
							
							thisButton.visible = true;
							thisButton.x = i - 88 + (x * 115);
							thisButton.y = yoffset + 21;
							
							thisButton.drawButton(mc, mouseX, mouseY, partialTicks);
							mc.getTextureManager().bindTexture(data.location);
							
							//skin
							Gui.drawScaledCustomSizeModalRect(i - 7 + (x * 115), yoffset + 5, 8, 8, 8, 8, 24, 24, data.width, data.height);
					
							//online display
							mc.getTextureManager().bindTexture(STALKER_MOD_GUI);
							
							int type = 0;
							if(playerdata.getInGame()) {
								type = 0;
							} else if(playerdata.queuePos() > 0) {
								type = 2;
							} else {
								type = 1;
							}
							
							this.drawTexturedModalRect(i - 3 + (x * 115), yoffset + 30, 60, 236 + type * 5, 17, 5);
						
						}
						
						if(yoffset - 9 > j - 50) {	
							//name
							this.drawString(fontRenderer, (playerdata.needNameUpdate()?"\u00a7m":"") + playerdata.getOldName(), i - 85 + (x * 115), yoffset - 9, Color.WHITE.getRGB());
						}
						
						if(yoffset + 8 < j + 97) {
							this.drawString(fontRenderer, "Queue:", i - 85 + (x * 115), yoffset + 8, Color.WHITE.getRGB());
							this.drawString(fontRenderer, (playerdata.queuePos()==-1)?"N/A":""+playerdata.queuePos(), i - 50 + (x * 115), yoffset + 8, Color.WHITE.getRGB());
						}
					
					}
			
				}	
			
			}
		}
		
		//draw background top & bottom
		mc.getTextureManager().bindTexture(STALKER_MOD_GUI);
		this.drawTexturedModalRect(i - 93, j - 50, 7, 0, 230, 31);
		this.drawTexturedModalRect(i - 93, j + 97, 7, 147, 230, 31);
		
		if(errorTick > -1) {
			errorTick--;
			this.drawString(fontRenderer, errorMessage, i + 85, j - 35, Color.RED.getRGB());
		}
		
		if(messageTick > -1) {
			messageTick--;
			this.drawString(fontRenderer, message, i + 85, j - 35, Color.GREEN.getRGB());
		}
		
		nameField.drawTextBox();
		
		this.drawString(fontRenderer, sign, i + 132, j + 110, taeTextColor.getRGB());
		
		super.drawScreen(mouseX, mouseY, partialTicks);
		
	}
	
	@Override
	public boolean doesGuiPauseGame() {
	    return false;
	}
	
	public void updateResourceMap() {
		
		Set<String> alertuuids = PlayerAlert.getUUIDPlayerName().keySet();
				
		//If no longer an alert, remove
		for(String uuid : new HashSet<String>(resourcemap.keySet())) {
			if(!alertuuids.contains(uuid)) {
				resourcemap.remove(uuid);
			}
		}
		
		
		//Update texture if needed 	
		for(String uuid : resourcemap.keySet()) {
			PlayerTextureData data = resourcemap.get(uuid);
			if(data.update) {
				try {
										
					String url = MojangGetter.getTexturesFromUUID(uuid);
															
					URL skinURL = new URL(url);
								
					BufferedImage skinImage = ImageIO.read(skinURL);
			
					data.width = skinImage.getTileWidth();
					data.height = skinImage.getTileHeight();
			
					data.image = skinImage;
					
					//DynamicTexture skinTexture = new DynamicTexture(skinImage);
												
					//data.location = mc.getTextureManager().getDynamicTextureLocation(skinURL.getFile(), skinTexture);
				
					data.update = false;
																
				} catch (Exception e) {
									
					//new TAEModException(e.getClass(), e.getMessage()).post();
					
					data.height = 64;
					data.width = 64;
					data.location = DEFAULT_SKIN;
					data.update = true;
					
				}
			}
		}
		
		//Add all new alerts
		for(String uuid : alertuuids) {
			if(!resourcemap.containsKey(uuid)) {	
				try {
								
					String url = MojangGetter.getTexturesFromUUID(uuid);
					
										
					URL skinURL = new URL(url);
					
			
					BufferedImage skinImage = ImageIO.read(skinURL);
					
			
					int imagewidth = skinImage.getTileWidth();
					int imageheight = skinImage.getTileHeight();
			
					//DynamicTexture skinTexture = new DynamicTexture(skinImage);
					
												
					//ResourceLocation location = mc.getTextureManager().getDynamicTextureLocation(skinURL.getFile(), skinTexture);
					
				
					boolean update = false;
										
					
					resourcemap.put(uuid, new PlayerTextureData(imagewidth, imageheight, skinImage, update));
				
				} catch (Exception e) {
					
					//new TAEModException(e.getClass(), e.getMessage()).post();
					resourcemap.put(uuid, new PlayerTextureData(64, 64, DEFAULT_SKIN, true));

				}
			}
		}
		
		PlayerAlert.updateQueuePositions();
		
	}
	
    private boolean needsScrollBars() {
    	return resourcemap.keySet().size() > 4;
    }
    
    private void updateTextColor() {
		int red = taeTextColor.getRed();
		int green = taeTextColor.getGreen();
		int blue = taeTextColor.getBlue();
		
		if(blue == 255) {
			if(green == 0) {
				red+=5;
			}
			if(red == 0) {
				green-=5;
			}
		}
		if(red == 255) {
			if(blue == 0) {
				green+=5;
			}
			if(green == 0) {
				blue-=5;
			}
		}
		if(green == 255) {
			if(red == 0) {
				blue+=5;
			}
			if(blue == 0) {
				red-=5;
			}
		}
		
		taeTextColor = new Color(red, green, blue, 255);
		
	}
    
    
    public static class PlayerTextureData {
    	
    	private int width;
    	private int height;
    	private BufferedImage image;
    	private ResourceLocation location;
    	private boolean update;
    	
    	private PlayerTextureData(int width, int height, BufferedImage image, boolean update) {
    		this.width = width;
    		this.height = height;
    		this.image = image;
    		this.update = update;
    		location = null;
    	}
    	
    	private PlayerTextureData(int width, int height, ResourceLocation location, boolean update) {
    		this.width = width;
    		this.height = height;
    		this.location = location;
    		this.update = update;
    	}
    	
    	public int getWidth() {
    		return width;
    	}
    	
    	public int getHeight() {
    		return height;
    	}
    	
    	public ResourceLocation getResource() {
    		//TODO: deep copy
    		return location;
    	}
    	
    }
	
}
