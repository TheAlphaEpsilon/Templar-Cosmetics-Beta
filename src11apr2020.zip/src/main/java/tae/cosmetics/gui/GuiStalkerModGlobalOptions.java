package tae.cosmetics.gui;

import java.awt.Color;
import java.io.IOException;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiPageButtonList.GuiResponder;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSlider;
import net.minecraft.client.gui.GuiSlider.FormatHelper;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import tae.cosmetics.mods.QueuePeekMod;
import tae.cosmetics.util.API2b2tdev;
import tae.cosmetics.util.PlayerAlert;

public class GuiStalkerModGlobalOptions extends GuiScreen {
	
	private static final ResourceLocation PLAYER_OPTIONS = new ResourceLocation("taecosmetics","textures/gui/playeroptions.png");

	private GuiButton toggleAlertOn;
	private GuiButton toggleAlertOff;

	private GuiButton toggleQueueOn;
	private GuiButton toggleQueueOff;
	
	private GuiButton updateQueue;
	private GuiSlider updateQueueTimer;
	
	private GuiButton back;
	
	private TempMessage[] messages;
	
	private static final int xOffset = -5;
	private static final int yOffset = 0;

	public GuiStalkerModGlobalOptions() {
		
		messages = new TempMessage[5];
		
		toggleAlertOn = new GuiButton(0, 50, 50, 175, 20, "Toggle All Alert Notifications On");
 		toggleAlertOff = new GuiButton(1, 200, 50, 175, 20, "Toggle All Alert Notifications Off");
 		
 		toggleQueueOn = new GuiButton(2, 50, 80, 175, 20, "Toggle All Queue Notifications On");
 		toggleQueueOff = new GuiButton(3, 200, 80, 175, 20, "Toggle All Queue Notifications Off");
 		
 		updateQueue = new GuiButton(4, 50, 110, 175, 20, "Update 2b2t Queue Cache");
		updateQueueTimer = new GuiSlider(new GuiResponder() {

			@Override
			public void setEntryValue(int id, boolean value) {				
			}

			@Override
			public void setEntryValue(int id, float value) {				
			}

			@Override
			public void setEntryValue(int id, String value) {				
			}
			
		}, 6, 200, 110, "TEST", 0, 60, QueuePeekMod.minutes, new FormatHelper()  {

			@Override
			public String getText(int id, String name, float value) {
				return null;
			}
			
		});
		
 		back = new GuiButton(5, 50, 140, 35, 20, "Back");

 		
	}
		
	@Override
	public void initGui() {
		super.initGui();
				
		messages[0] = new TempMessage("All alerts toggled on", Color.GREEN);
		messages[1] = new TempMessage("All alerts toggled off", Color.RED);
		messages[2] = new TempMessage("All queue alerts on", Color.GREEN);
		messages[3] = new TempMessage("All queue alerts off", Color.RED);
		messages[4] = new TempMessage("Updated", Color.WHITE);
		
		buttonList.add(toggleAlertOn);
		buttonList.add(toggleAlertOff);

		buttonList.add(toggleQueueOn);
		buttonList.add(toggleQueueOff);

		buttonList.add(updateQueue);
		buttonList.add(updateQueueTimer);
		
		buttonList.add(back);
	}
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
				
		int i = width / 2 + xOffset;
		int j = height / 2 + yOffset;
		
		GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.disableLighting();
		GlStateManager.enableAlpha();
		GlStateManager.enableBlend();
		
		mc.getTextureManager().bindTexture(PLAYER_OPTIONS);
		Gui.drawScaledCustomSizeModalRect(i - 200, j - 90, 0, 0, 242, 192, 410, 180, 256, 256);
		
		String toSend = "Queue update timer: " + (((int)updateQueueTimer.getSliderValue() == 0) ? "Disabled" : ((int)updateQueueTimer.getSliderValue() + "m"));
		this.drawString(fontRenderer, toSend, i + 20, j + 35, Color.WHITE.getRGB());
		
		updateButtonPos(i, j);
		super.drawScreen(mouseX, mouseY, partialTicks);
		
		for(int index = 0; index < 5; index++) {
		
			int row = index / 2 ;
			
			messages[index].displayOnTick(i - 175 + ((index % 2 == 0) ? 0 : 200), j - 45 + (row * 40), fontRenderer);
			
		}
		
	}
	
	@Override
	public boolean doesGuiPauseGame() {
	    return false;
	}
	
	@Override
	public void onGuiClosed() {
		QueuePeekMod.minutes = (int)updateQueueTimer.getSliderValue();
		super.onGuiClosed();
		Keyboard.enableRepeatEvents(false);
	}
	
	@Override
	protected void actionPerformed(GuiButton button) throws IOException {
		if(button == toggleAlertOn) {
			PlayerAlert.toggleAllAlerts(true);
			messages[0].setTicks(250);
		} else if(button == toggleAlertOff) {
			PlayerAlert.toggleAllAlerts(false);
			messages[1].setTicks(250);
		} else if(button == toggleQueueOn) {
			PlayerAlert.toggleAllQueue(true);
			messages[2].setTicks(250);
		} else if(button == toggleQueueOff) {
			PlayerAlert.toggleAllQueue(false);
			messages[3].setTicks(250);
		} else if(button == updateQueue) {
			QueuePeekMod.initAndUpdate();
			API2b2tdev.update();
			messages[4].setTicks(250);
		} else if(button == back) {
			mc.addScheduledTask(() -> {
				//mc.displayGuiScreen(null);
				mc.displayGuiScreen(GuiStalkerMod.instance());
			});
		}
	}
	
	private void updateButtonPos(int xOffset, int yOffset) {
		
		toggleAlertOn.x = xOffset - 180;
		toggleAlertOn.y = yOffset - 70;
		
		toggleAlertOff.x = xOffset + 20;
		toggleAlertOff.y = yOffset - 70;
		
		toggleQueueOn.x = xOffset - 180;
		toggleQueueOn.y = yOffset - 30;
		
		toggleQueueOff.x = xOffset + 20;
		toggleQueueOff.y = yOffset - 30;
		
		updateQueue.x = xOffset - 180;
		updateQueue.y = yOffset + 10;
		
		updateQueueTimer.x = xOffset + 20;
		updateQueueTimer.y = yOffset + 10;
		
		back.x = xOffset - 180;
		back.y = yOffset + 50;
		
	}
	
	class TempMessage extends GuiScreen{
		
		private String message;
		private int ticks = -1;
		private Color color;
		
		private TempMessage(String message, Color color) {
			this.message = message;
			this.ticks = -1;
			this.color = color;
		}
		
		private void setTicks(int ticks) {
			this.ticks = ticks;
		}
		
		private void displayOnTick(int x, int y, FontRenderer renderer) {
			if(ticks > -1) {
				ticks--;
				drawString(renderer, message, x, y, color.getRGB());
			}
		}
		
	}
	
}
