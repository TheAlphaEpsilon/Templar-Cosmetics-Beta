package tae.cosmetics.gui;

import java.io.IOException;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public abstract class AbstractTAEGuiScreen extends GuiScreen {
	
	//TODO: Implement
	
	private GuiScreen parent;
	
	protected GuiButton back = new GuiButton(0, 0, 0, 70, 20, "Back");
	
	protected AbstractTAEGuiScreen(GuiScreen parent) {
		this.parent = parent;
		buttonList.add(back);
	}
		
	@Override
	protected void actionPerformed(GuiButton button) throws IOException {
		
		if(button == back) {
			
			displayScreen(parent);
			
		}
		
	}
	
	@Override
	public boolean doesGuiPauseGame() {
	    return false;
	}
	
	protected void displayScreen(GuiScreen screenIn) {
		mc.addScheduledTask(() -> {
			
			mc.displayGuiScreen(screenIn);
			
		});
	}
	
	@Override
	public abstract void initGui();
	
	@Override
	public abstract void onGuiClosed();
	
	@Override
	protected abstract void keyTyped(char typedChar, int keyCode) throws IOException;
	
	@Override
	protected abstract void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException;
	
	@Override
	public abstract void drawScreen(int mouseX, int mouseY, float partialTicks);
	
	protected abstract void updateButtonPositions();
	
}
