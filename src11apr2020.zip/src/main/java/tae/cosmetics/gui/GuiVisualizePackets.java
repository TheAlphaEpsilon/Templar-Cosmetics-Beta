package tae.cosmetics.gui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.*;
import net.minecraft.network.play.server.*;
import net.minecraft.network.status.client.CPacketPing;
import net.minecraft.network.status.server.SPacketPong;
import net.minecraft.network.status.server.SPacketServerInfo;
import net.minecraft.util.ResourceLocation;
import tae.cosmetics.gui.util.GuiExtendPacketModuleButton;
import tae.cosmetics.gui.util.GuiMorePacketInformationButton;
import tae.cosmetics.gui.util.ScrollBar;
import tae.cosmetics.gui.util.packet.server.*;
import tae.cosmetics.mods.VisualizePacketsMod;
import tae.cosmetics.gui.util.packet.AbstractPacketModule;
import tae.cosmetics.gui.util.packet.TimestampModule;
import tae.cosmetics.gui.util.packet.UnknownPacketModule;
import tae.cosmetics.gui.util.packet.client.*;

public class GuiVisualizePackets extends GuiScreen {
	
	//TODO: filter packets
	
    private static final ResourceLocation BACKGROUND = new ResourceLocation("taecosmetics","textures/gui/cancelpackets.png");

    public static final int spacing = 4;
        
    private static int minY;
    private static int maxY;
    
	private EncapsulatedModuleList modulesToDraw;
	
	private ScrollBar scroll = new ScrollBar(0, 0, 139);
	
	private int topIndex = 0;
	
	private int modulesHeight = 0;
	
	private int oldModulesSize = 0;
		
	private static GuiVisualizePackets INSTANCE;
		
	private GuiButton back = new GuiButton(-1, 0, 0, 70, 20, "Back");
	
	private GuiVisualizePackets() {
		this.reset();
	}
	
	public static GuiVisualizePackets instance() {
		if(INSTANCE == null) {
			INSTANCE = new GuiVisualizePackets();
		}
		return INSTANCE;
	}

	@Override
	public void initGui() {
				
		VisualizePacketsMod.forceStop();
		
		buttonList.add(back);
		
		minY = height / 2;
		maxY = minY + AbstractPacketModule.modheightfull * 2;
		
		modulesHeight = 0;
		
		oldModulesSize = modulesToDraw.size();
		
		for(AbstractPacketModuleEncapsulation encapsuled : modulesToDraw) {
			
			this.buttonList.add(encapsuled.button);
			this.buttonList.add(encapsuled.more);
			
			AbstractPacketModule module = encapsuled.module;
			
			if(module.isMinimized()) {
				modulesHeight += AbstractPacketModule.modheightminimized;
			} else {
				modulesHeight += AbstractPacketModule.modheightfull;
			}
			
			modulesHeight += spacing;
			
		}
		
		modulesHeight -= maxY - minY;
		
	}
	
	@Override
	public void onGuiClosed() {
		
	}
	
	@Override
	protected void actionPerformed(GuiButton button) throws IOException {
		
		if(button == back) {
			mc.addScheduledTask(() -> {
				mc.displayGuiScreen(Gui2b2tcp.instance());
			});
		}
		
		if(button instanceof GuiExtendPacketModuleButton) {
			((GuiExtendPacketModuleButton) button).toggle();
			this.updateMinimzation(((GuiExtendPacketModuleButton) button).module, !((GuiExtendPacketModuleButton) button).getExtended());
		} else if(button instanceof GuiMorePacketInformationButton) {
			((GuiMorePacketInformationButton) button).openScreen(this);
		}
	}
	
	@Override
	protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
		super.mouseClicked(mouseX, mouseY, mouseButton);
	}
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		
		if(modulesToDraw.size() > oldModulesSize) {
			for(int index = oldModulesSize; index < modulesToDraw.size(); index++) {
				
				this.buttonList.add(modulesToDraw.get(index).button);
				this.buttonList.add(modulesToDraw.get(index).more);
				
				if(modulesToDraw.get(index).module.isMinimized()) {
					modulesHeight += AbstractPacketModule.modheightminimized;
				} else {
					modulesHeight += AbstractPacketModule.modheightfull;
				}
				
				modulesHeight += spacing;
			}
			oldModulesSize = modulesToDraw.size();
		}
		
		int i = width / 2;
		int j = height / 2;
		
		GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.disableLighting();
		GlStateManager.enableAlpha();
		GlStateManager.enableBlend();
		
		mc.getTextureManager().bindTexture(BACKGROUND);
		
		this.drawTexturedModalRect(i - 213, j - 120, 0, 0, 128, 205);
		
		this.drawTexturedModalRect(i - 213, j - 14, 0, 77, 128, 205);
		
		this.drawTexturedModalRect(i - 85, j - 120, 4, 0, 240, 205);
		
		this.drawTexturedModalRect(i - 85, j - 86, 4, 5, 240, 206);
		
		this.drawTexturedModalRect(i + 86, j - 120, 128, 0, 128, 211);
		
		this.drawTexturedModalRect(i + 86, j - 14, 128, 77, 128, 205);
		
		updateButtonLocations(i, j);
		
		if(modulesHeight < maxY) {
			scroll.setDisabled(true);
		} else {
			scroll.setDisabled(false);
		}
				
		scroll.draw(mouseX, mouseY);
		
		AbstractPacketModule lastHovered = null;
		AbstractPacketModule prev = null;
		int index = topIndex;
		
		for(AbstractPacketModuleEncapsulation encapsuled : modulesToDraw) {
						
			AbstractPacketModule module = encapsuled.module;
			
			if(prev == null) {
				
				module.y = (int) (minY - (scroll.getScroll() * modulesHeight) );
				
				
			} else {
				
				module.y = prev.y + spacing + (prev.isMinimized() ? AbstractPacketModule.modheightminimized : AbstractPacketModule.modheightfull);

			}
			
			module.x = i - (AbstractPacketModule.modwidth) / 4;
			
			if(module.y > minY - spacing - (module.isMinimized() ? AbstractPacketModule.modheightminimized : AbstractPacketModule.modheightfull) &&
					module.y < maxY + spacing + (module.isMinimized() ? AbstractPacketModule.modheightminimized : AbstractPacketModule.modheightfull)) {
				module.drawScreen(mouseX, mouseY, partialTicks);
			}
									
			encapsuled.button.x = module.x - 20;
			encapsuled.button.y = module.y;
			
			encapsuled.more.x = module.x + AbstractPacketModule.modtimestampwidth * 3 + AbstractPacketModule.modwidth + 30;
			encapsuled.more.y = module.y;
			
			if(encapsuled.module.y < minY && encapsuled.module.y > maxY - 20) {
				encapsuled.button.enabled = false;
				encapsuled.more.enabled = false;
			} else {
				encapsuled.button.enabled = true;
				encapsuled.more.enabled = true;
			}
			
			if(encapsuled.module.y > minY - (module.isMinimized() ? AbstractPacketModule.modheightminimized : AbstractPacketModule.modheightfull) &&
					encapsuled.module.y < maxY + (module.isMinimized() ? AbstractPacketModule.modheightminimized : AbstractPacketModule.modheightfull) ) {
				encapsuled.button.drawButton(mc, mouseX, mouseY, partialTicks);
				encapsuled.more.drawButton(mc, mouseX, mouseY, partialTicks);
			}
			
			if(module.isHovered(mouseX, mouseY)) {
				lastHovered = module;
			}
			
			prev = module;

		}
				
		GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.enableBlend();
		mc.getTextureManager().bindTexture(BACKGROUND);
		
		int diff = (minY / 2) - (j - 120) - (spacing / 2);
		
		Gui.drawScaledCustomSizeModalRect(i - 200, j - 120, 5, 0, 230, diff, 370, diff, 256, 256);
		
		int diff2 = (j + 114) - (maxY / 2) - (spacing / 2);
				
		Gui.drawScaledCustomSizeModalRect(i - 200, j + 120 - diff2, 5, 211 - diff2, 230, diff2, 370, diff2, 256, 256);
				
		if(lastHovered != null && lastHovered.isHovered(mouseX, mouseY) && mouseY > minY / 2 && mouseY < maxY / 2) {
			drawHoveringText(Arrays.asList(lastHovered.getTip()), mouseX, mouseY, fontRenderer);
		}
		
		back.drawButton(mc, mouseX, mouseY, partialTicks);
				
	}
	
	@Override
	public boolean doesGuiPauseGame() {
	    return false;
	}	
	
	private void updateButtonLocations(int x, int y) {
		scroll.x = x + 194;
		scroll.y = y - 68;
	}
	
	private void updateMinimzation(AbstractPacketModule module, boolean bool) {
		if(module.isMinimized() == bool) {
			return;
		} else {
			
			if(bool) {
				module.setMinimized(bool);
				modulesHeight -= AbstractPacketModule.modheightfull - AbstractPacketModule.modheightminimized;
			} else {
				module.setMinimized(bool);
				modulesHeight += AbstractPacketModule.modheightfull - AbstractPacketModule.modheightminimized;
			}
			
		}
	}
	
	public void reset() {
		
		if(modulesToDraw == null || !modulesToDraw.isEmpty()) {
			modulesToDraw = new EncapsulatedModuleList();
		}
		
		scroll.setScroll(0);
	}
	
	public void addMarker(TimestampModule module) {
		modulesToDraw.add(module);
	}
	
	//Epic coder skillz upcoming
	
	public void addClientPacket(Packet<?> packet, long timestamp) {
	
		if(packet instanceof CPacketAnimation) {
			modulesToDraw.add(new CPacketAnimationModule((CPacketAnimation) packet, timestamp));
		} else if(packet instanceof CPacketChatMessage) {
			modulesToDraw.add(new CPacketChatMessageModule((CPacketChatMessage) packet, timestamp));
		} else if(packet instanceof CPacketClickWindow) {
			modulesToDraw.add(new CPacketClickWindowModule((CPacketClickWindow) packet, timestamp));
		} else if(packet instanceof CPacketClientSettings) {
			modulesToDraw.add(new CPacketClientSettingsModule((CPacketClientSettings) packet, timestamp));
		} else if(packet instanceof CPacketClientStatus) {
			modulesToDraw.add(new CPacketClientStatusModule((CPacketClientStatus) packet, timestamp));
		} else if(packet instanceof CPacketCloseWindow) {
			modulesToDraw.add(new CPacketCloseWindowModule((CPacketCloseWindow) packet, timestamp));
		} else if(packet instanceof CPacketConfirmTeleport) {
			modulesToDraw.add(new CPacketConfirmTeleportModule((CPacketConfirmTeleport) packet, timestamp));
		} else if(packet instanceof CPacketConfirmTransaction) {
			modulesToDraw.add(new CPacketConfirmTransactionModule((CPacketConfirmTransaction) packet, timestamp));
		} else if(packet instanceof CPacketCreativeInventoryAction) {
			modulesToDraw.add(new CPacketCreativeInventoryActionModule((CPacketCreativeInventoryAction) packet, timestamp));
		} else if(packet instanceof CPacketCustomPayload) {
			modulesToDraw.add(new CPacketCustomPayloadModule((CPacketCustomPayload) packet, timestamp));
		} else if(packet instanceof CPacketEnchantItem) {
			modulesToDraw.add(new CPacketEnchantItemModule((CPacketEnchantItem) packet, timestamp));
		} else if(packet instanceof CPacketEntityAction) {
			modulesToDraw.add(new CPacketEntityActionModule((CPacketEntityAction) packet, timestamp));
		} else if(packet instanceof CPacketHeldItemChangeModule) {
			modulesToDraw.add(new CPacketHeldItemChangeModule((CPacketHeldItemChange) packet, timestamp));
		} else if(packet instanceof CPacketInput) {
			modulesToDraw.add(new CPacketInputModule((CPacketInput) packet, timestamp));
		} else if(packet instanceof CPacketKeepAlive) {
			modulesToDraw.add(new CPacketKeepAliveModule((CPacketKeepAlive) packet, timestamp));
		} else if(packet instanceof CPacketPing) {
			modulesToDraw.add(new CPacketPingModule((CPacketPing) packet, timestamp));
		} else if(packet instanceof CPacketPlayerAbilities) {
			modulesToDraw.add(new CPacketPlayerAbilitiesModule((CPacketPlayerAbilities) packet, timestamp));
		} else if(packet instanceof CPacketPlayerDigging) {
			modulesToDraw.add(new CPacketPlayerDiggingModule((CPacketPlayerDigging) packet, timestamp));
		} else if(packet instanceof CPacketPlayer) {
			modulesToDraw.add(new CPacketPlayerModule((CPacketPlayer) packet, timestamp));
		} else if(packet instanceof CPacketPlayerTryUseItem) {
			modulesToDraw.add(new CPacketPlayerTryUseItemModule((CPacketPlayerTryUseItem) packet, timestamp));
		} else if(packet instanceof CPacketPlayerTryUseItemOnBlock) {
			modulesToDraw.add(new CPacketPlayerTryUseItemOnBlockModule((CPacketPlayerTryUseItemOnBlock) packet, timestamp));
		} else if(packet instanceof CPacketRecipeInfo) {
			modulesToDraw.add(new CPacketRecipeInfoModule((CPacketRecipeInfo) packet, timestamp));
		} else if(packet instanceof CPacketResourcePackStatus) {
			modulesToDraw.add(new CPacketResourcePackStatusModule((CPacketResourcePackStatus) packet, timestamp));
		} else if(packet instanceof CPacketSeenAdvancements) {
			modulesToDraw.add(new CPacketSeenAdvancementsModule((CPacketSeenAdvancements) packet, timestamp));
		} else if(packet instanceof CPacketSpectate) {
			modulesToDraw.add(new CPacketSpectateModule((CPacketSpectate) packet, timestamp));
		} else if(packet instanceof CPacketSteerBoat) {
			modulesToDraw.add(new CPacketSteerBoatModule((CPacketSteerBoat) packet, timestamp));
		} else if(packet instanceof CPacketTabComplete) {
			modulesToDraw.add(new CPacketTabCompleteModule((CPacketTabComplete) packet, timestamp));
		} else if(packet instanceof CPacketUpdateSign) {
			modulesToDraw.add(new CPacketUpdateSignModule((CPacketUpdateSign) packet, timestamp));
		} else if(packet instanceof CPacketUseEntity) {
			modulesToDraw.add(new CPacketUseEntityModule((CPacketUseEntity) packet, timestamp));
		} else if(packet instanceof CPacketVehicleMove) {
			modulesToDraw.add(new CPacketVehicleMoveModule((CPacketVehicleMove) packet, timestamp));
		} else {
			modulesToDraw.add(new UnknownPacketModule(packet, timestamp, true));
		}
		
	}
	
	public void addServerPacket(Packet<?> packet, long timestamp) {

		if(packet instanceof SPacketAdvancementInfo) {
			modulesToDraw.add(new SPacketAdvancementInfoModule((SPacketAdvancementInfo) packet, timestamp));
		} else if(packet instanceof SPacketAnimation) {
			modulesToDraw.add(new SPacketAnimationModule((SPacketAnimation) packet, timestamp));
		} else if(packet instanceof SPacketBlockAction) {
			modulesToDraw.add(new SPacketBlockActionModule((SPacketBlockAction) packet, timestamp));
		} else if(packet instanceof SPacketBlockBreakAnim) {
			modulesToDraw.add(new SPacketBlockBreakAnimModule((SPacketBlockBreakAnim) packet, timestamp));
		} else if(packet instanceof SPacketBlockChange) {
			modulesToDraw.add(new SPacketBlockChangeModule((SPacketBlockChange) packet, timestamp));
		} else if(packet instanceof SPacketCamera) {
			modulesToDraw.add(new SPacketCameraModule((SPacketCamera) packet, timestamp));
		} else if(packet instanceof SPacketChangeGameState) {
			modulesToDraw.add(new SPacketChangeGameStateModule((SPacketChangeGameState) packet, timestamp));
		} else if(packet instanceof SPacketChat) {
			modulesToDraw.add(new SPacketChatModule((SPacketChat) packet, timestamp));
		} else if(packet instanceof SPacketChunkData) {
			modulesToDraw.add(new SPacketChunkDataModule((SPacketChunkData) packet, timestamp));
		} else if(packet instanceof SPacketCloseWindow) {
			modulesToDraw.add(new SPacketCloseWindowModule((SPacketCloseWindow) packet, timestamp));
		} else if(packet instanceof SPacketCollectItem) {
			modulesToDraw.add(new SPacketCollectItemModule((SPacketCollectItem) packet, timestamp));
		} else if(packet instanceof SPacketCombatEvent) {
			modulesToDraw.add(new SPacketCombatEventModule((SPacketCombatEvent) packet, timestamp));
		} else if(packet instanceof SPacketConfirmTransaction) {
			modulesToDraw.add(new SPacketConfirmTransactionModule((SPacketConfirmTransaction) packet, timestamp));
		} else if(packet instanceof SPacketCooldown) {
			modulesToDraw.add(new SPacketCooldownModule((SPacketCooldown) packet, timestamp));
		} else if(packet instanceof SPacketCustomPayload) {
			modulesToDraw.add(new SPacketCustomPayloadModule((SPacketCustomPayload) packet, timestamp));
		} else if(packet instanceof SPacketCustomSound) {
			modulesToDraw.add(new SPacketCustomSoundModule((SPacketCustomSound) packet, timestamp));
		} else if(packet instanceof SPacketDestroyEntities) {
			modulesToDraw.add(new SPacketDestroyEntitiesModule((SPacketDestroyEntities) packet, timestamp));
		} else if(packet instanceof SPacketDisplayObjective) {
			modulesToDraw.add(new SPacketDisplayObjectiveModule((SPacketDisplayObjective) packet, timestamp));
		} else if(packet instanceof SPacketEffect) {
			modulesToDraw.add(new SPacketEffectModule((SPacketEffect) packet, timestamp));
		} else if(packet instanceof SPacketEntity) {
			modulesToDraw.add(new SPacketEntityModule((SPacketEntity) packet, timestamp));
		} else if(packet instanceof SPacketEntityAttach) {
			modulesToDraw.add(new SPacketEntityAttachModule((SPacketEntityAttach) packet, timestamp));
		} else if(packet instanceof SPacketEntityEffect) {
			modulesToDraw.add(new SPacketEntityEffectModule((SPacketEntityEffect) packet, timestamp));
		} else if(packet instanceof SPacketEntityEquipment) {
			modulesToDraw.add(new SPacketEntityEquipmentModule((SPacketEntityEquipment) packet, timestamp));
		} else if(packet instanceof SPacketEntityHeadLook) {
			modulesToDraw.add(new SPacketEntityHeadLookModule((SPacketEntityHeadLook) packet, timestamp));
		} else if(packet instanceof SPacketEntityMetadata) {
			modulesToDraw.add(new SPacketEntityMetadataModule((SPacketEntityMetadata) packet, timestamp));
		} else if(packet instanceof SPacketEntityProperties) {
			modulesToDraw.add(new SPacketEntityPropertiesModule((SPacketEntityProperties) packet, timestamp));
		} else if(packet instanceof SPacketEntityStatus) {
			modulesToDraw.add(new SPacketEntityStatusModule((SPacketEntityStatus) packet, timestamp));
		} else if(packet instanceof SPacketEntityTeleport) {
			modulesToDraw.add(new SPacketEntityTeleportModule((SPacketEntityTeleport) packet, timestamp));
		} else if(packet instanceof SPacketEntityVelocity) {
			modulesToDraw.add(new SPacketEntityVelocityModule((SPacketEntityVelocity) packet, timestamp));
		} else if(packet instanceof SPacketExplosion) {
			modulesToDraw.add(new SPacketExplosionModule((SPacketExplosion) packet, timestamp));
		} else if(packet instanceof SPacketHeldItemChange) {
			modulesToDraw.add(new SPacketHeldItemChangeModule((SPacketHeldItemChange) packet, timestamp));
		} else if(packet instanceof SPacketKeepAlive) {
			modulesToDraw.add(new SPacketKeepAliveModule((SPacketKeepAlive) packet, timestamp));
		} else if(packet instanceof SPacketMaps) {
			modulesToDraw.add(new SPacketMapsModule((SPacketMaps) packet, timestamp));
		} else if(packet instanceof SPacketMoveVehicle) {
			modulesToDraw.add(new SPacketMoveVehicleModule((SPacketMoveVehicle) packet, timestamp));
		} else if(packet instanceof SPacketMultiBlockChange) {
			modulesToDraw.add(new SPacketMultiBlockChangeModule((SPacketMultiBlockChange) packet, timestamp));
		} else if(packet instanceof SPacketOpenWindow) {
			modulesToDraw.add(new SPacketOpenWindowModule((SPacketOpenWindow) packet, timestamp));
		} else if(packet instanceof SPacketParticles) {
			modulesToDraw.add(new SPacketParticlesModule((SPacketParticles) packet, timestamp));
		} else if(packet instanceof SPacketPlayerAbilities) {
			modulesToDraw.add(new SPacketPlayerAbilitiesModule((SPacketPlayerAbilities) packet, timestamp));
		} else if(packet instanceof SPacketPlayerListHeaderFooter) {
			modulesToDraw.add(new SPacketPlayerListHeaderFooterModule((SPacketPlayerListHeaderFooter) packet, timestamp));
		} else if(packet instanceof SPacketPlayerListItem) {
			modulesToDraw.add(new SPacketPlayerListItemModule((SPacketPlayerListItem) packet, timestamp));
		} else if(packet instanceof SPacketPlayerPosLook) {
			modulesToDraw.add(new SPacketPlayerPosLookModule((SPacketPlayerPosLook) packet, timestamp));
		} else if(packet instanceof SPacketPong) {
			modulesToDraw.add(new SPacketPongModule((SPacketPong) packet, timestamp));
		} else if(packet instanceof SPacketRecipeBook) {
			modulesToDraw.add(new SPacketRecipeBookModule((SPacketRecipeBook) packet, timestamp));
		} else if(packet instanceof SPacketRemoveEntityEffect) {
			modulesToDraw.add(new SPacketRemoveEntityEffectModule((SPacketRemoveEntityEffect) packet, timestamp));
		} else if(packet instanceof SPacketResourcePackSend) {
			modulesToDraw.add(new SPacketResourcePackSendModule((SPacketResourcePackSend) packet, timestamp));
		} else if(packet instanceof SPacketRespawn) {
			modulesToDraw.add(new SPacketRespawnModule((SPacketRespawn) packet, timestamp));
		} else if(packet instanceof SPacketScoreboardObjective) {
			modulesToDraw.add(new SPacketScoreboardObjectiveModule((SPacketScoreboardObjective) packet, timestamp));
		} else if(packet instanceof SPacketSelectAdvancementsTab) {
			modulesToDraw.add(new SPacketSelectAdvancementsTabModule((SPacketSelectAdvancementsTab) packet, timestamp));
		} else if(packet instanceof SPacketServerDifficulty) {
			modulesToDraw.add(new SPacketServerDifficultyModule((SPacketServerDifficulty) packet, timestamp));
		} else if(packet instanceof SPacketServerInfo) {
			modulesToDraw.add(new SPacketServerInfoModule((SPacketServerInfo) packet, timestamp));
		} else if(packet instanceof SPacketSetExperience) {
			modulesToDraw.add(new SPacketSetExperienceModule((SPacketSetExperience) packet, timestamp));
		} else if(packet instanceof SPacketSetPassengers) {
			modulesToDraw.add(new SPacketSetPassengersModule((SPacketSetPassengers) packet, timestamp));
		} else if(packet instanceof SPacketSetSlot) {
			modulesToDraw.add(new SPacketSetSlotModule((SPacketSetSlot) packet, timestamp));
		} else if(packet instanceof SPacketSignEditorOpen) {
			modulesToDraw.add(new SPacketSignEditorOpenModule((SPacketSignEditorOpen) packet, timestamp));
		} else if(packet instanceof SPacketSoundEffect) {
			modulesToDraw.add(new SPacketSoundEffectModule((SPacketSoundEffect) packet, timestamp));
		} else if(packet instanceof SPacketSpawnExperienceOrb) {
			modulesToDraw.add(new SPacketSpawnExperienceOrbModule((SPacketSpawnExperienceOrb) packet, timestamp));
		} else if(packet instanceof SPacketSpawnGlobalEntity) {
			modulesToDraw.add(new SPacketSpawnGlobalEntityModule((SPacketSpawnGlobalEntity) packet, timestamp));
		} else if(packet instanceof SPacketSpawnMob) {
			modulesToDraw.add(new SPacketSpawnMobModule((SPacketSpawnMob) packet, timestamp));
		} else if(packet instanceof SPacketSpawnObject) {
			modulesToDraw.add(new SPacketSpawnObjectModule((SPacketSpawnObject) packet, timestamp));
		} else if(packet instanceof SPacketSpawnPainting) {
			modulesToDraw.add(new SPacketSpawnPaintingModule((SPacketSpawnPainting) packet, timestamp));
		} else if(packet instanceof SPacketSpawnPlayer) {
			modulesToDraw.add(new SPacketSpawnPlayerModule((SPacketSpawnPlayer) packet, timestamp));
		} else if(packet instanceof SPacketSpawnPosition) {
			modulesToDraw.add(new SPacketSpawnPositionModule((SPacketSpawnPosition) packet, timestamp));
		} else if(packet instanceof SPacketStatistics) {
			modulesToDraw.add(new SPacketStatisticsModule((SPacketStatistics) packet, timestamp));
		} else if(packet instanceof SPacketTabComplete) {
			modulesToDraw.add(new SPacketTabCompleteModule((SPacketTabComplete) packet, timestamp));
		} else if(packet instanceof SPacketTeams) {
			modulesToDraw.add(new SPacketTeamsModule((SPacketTeams) packet, timestamp));
		} else if(packet instanceof SPacketTimeUpdate) {
			modulesToDraw.add(new SPacketTimeUpdateModule((SPacketTimeUpdate) packet, timestamp));
		} else if(packet instanceof SPacketTitle) {
			modulesToDraw.add(new SPacketTitleModule((SPacketTitle) packet, timestamp));
		} else if(packet instanceof SPacketUnloadChunk) {
			modulesToDraw.add(new SPacketUnloadChunkModule((SPacketUnloadChunk) packet, timestamp));
		} else if(packet instanceof SPacketUpdateBossInfo) {
			modulesToDraw.add(new SPacketUpdateBossInfoModule((SPacketUpdateBossInfo) packet, timestamp));
		} else if(packet instanceof SPacketUpdateHealth) {
			modulesToDraw.add(new SPacketUpdateHealthModule((SPacketUpdateHealth) packet, timestamp));
		} else if(packet instanceof SPacketUpdateScore) {
			modulesToDraw.add(new SPacketUpdateScoreModule((SPacketUpdateScore) packet, timestamp));
		} else if(packet instanceof SPacketUpdateTileEntity) {
			modulesToDraw.add(new SPacketUpdateTileEntityModule((SPacketUpdateTileEntity) packet, timestamp));
		} else if(packet instanceof SPacketUseBed) {
			modulesToDraw.add(new SPacketUseBedModule((SPacketUseBed) packet, timestamp));
		} else if(packet instanceof SPacketWindowItems) {
			modulesToDraw.add(new SPacketWindowItemsModule((SPacketWindowItems) packet, timestamp));
		} else if(packet instanceof SPacketWindowProperty) {
			modulesToDraw.add(new SPacketWindowPropertyModule((SPacketWindowProperty) packet, timestamp));
		} else if(packet instanceof SPacketWorldBorder) {
			modulesToDraw.add(new SPacketWorldBorderModule((SPacketWorldBorder) packet, timestamp));
		} else {
			modulesToDraw.add(new UnknownPacketModule(packet, timestamp, false));
		}
		
	}
	
	@Override
	protected void drawHoveringText(List<String> textLines, int x, int y, FontRenderer font) {
        if (!textLines.isEmpty()) {
            
            int i = 0;

            for (String s : textLines)
            {
                int j = this.fontRenderer.getStringWidth(s);

                if (j > i)
                {
                    i = j;
                }
            }

            int l1 = x + 12;
            int i2 = y - 12;
            int k = 8;

            if (textLines.size() > 1)
            {
                k += 2 + (textLines.size() - 1) * 10;
            }

            this.drawGradientRect(l1 - 3, i2 - 4, l1 + i + 3, i2 - 3, -267386864, -267386864);
            this.drawGradientRect(l1 - 3, i2 + k + 3, l1 + i + 3, i2 + k + 4, -267386864, -267386864);
            this.drawGradientRect(l1 - 3, i2 - 3, l1 + i + 3, i2 + k + 3, -267386864, -267386864);
            this.drawGradientRect(l1 - 4, i2 - 3, l1 - 3, i2 + k + 3, -267386864, -267386864);
            this.drawGradientRect(l1 + i + 3, i2 - 3, l1 + i + 4, i2 + k + 3, -267386864, -267386864);
            this.drawGradientRect(l1 - 3, i2 - 3 + 1, l1 - 3 + 1, i2 + k + 3 - 1, 1347420415, 1344798847);
            this.drawGradientRect(l1 + i + 2, i2 - 3 + 1, l1 + i + 3, i2 + k + 3 - 1, 1347420415, 1344798847);
            this.drawGradientRect(l1 - 3, i2 - 3, l1 + i + 3, i2 - 3 + 1, 1347420415, 1347420415);
            this.drawGradientRect(l1 - 3, i2 + k + 2, l1 + i + 3, i2 + k + 3, 1344798847, 1344798847);

            for (int k1 = 0; k1 < textLines.size(); ++k1)
            {
                String s1 = textLines.get(k1);
                this.fontRenderer.drawStringWithShadow(s1, (float)l1, (float)i2, -1);

                if (k1 == 0)
                {
                    i2 += 2;
                }

                i2 += 10;
            }
            
        }
        
    }

	
	
	class EncapsulatedModuleList extends ArrayList<AbstractPacketModuleEncapsulation> {

		private static final long serialVersionUID = 1L;
		
		private int counter = 0;
		
		public boolean add(AbstractPacketModule module) {
			
			return super.add(new AbstractPacketModuleEncapsulation(module));
			
		}
		
	}
	
	class AbstractPacketModuleEncapsulation {
		
		public AbstractPacketModule module;
		public GuiExtendPacketModuleButton button;
		public GuiMorePacketInformationButton more;
		
		private AbstractPacketModuleEncapsulation(AbstractPacketModule module) {
			this.module = module;
			this.button = new GuiExtendPacketModuleButton(0, 0, 0, module);
			this.more = new GuiMorePacketInformationButton(1, 0, 0, module.packet);
		}
		
	}
	
}
