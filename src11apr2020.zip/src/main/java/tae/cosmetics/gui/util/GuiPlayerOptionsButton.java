package tae.cosmetics.gui.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import tae.cosmetics.gui.GuiStalkerMod.PlayerTextureData;

public class GuiPlayerOptionsButton extends GuiButton {

	private static final ResourceLocation STALKER_MOD_GUI = new ResourceLocation("taecosmetics","textures/gui/playeralert.png");
	
	public PlayerTextureData playerTexture;
	private String uuid;
	private int maxY;
	private int minY;
	
	public GuiPlayerOptionsButton(int buttonId, int x, int y, int width, int height, String uuid, PlayerTextureData playerTexture, int maxY, int minY) {
		super(buttonId, x, y, width, height, null);
		this.uuid = uuid;
		this.playerTexture = playerTexture;
		this.maxY = maxY;
		this.minY = minY;
	}
	
	public void setUUID(String uuid) {
		this.uuid = uuid;
	}
	
	public String getUUID() {
		return uuid;
	}
	
	@Override
	public void drawButton(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
		if(this.visible) {
			
			this.hovered = mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= ((this.y < minY) ? minY : this.y) && mouseY <= ((this.y + this.height > maxY) ? maxY : this.y + this.height);
			
			
			int i = this.getHoverState(this.hovered) - 1;
      
			GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
			GlStateManager.disableLighting();
			GlStateManager.enableAlpha();
			GlStateManager.enableBlend();
			mc.getTextureManager().bindTexture(STALKER_MOD_GUI);
			
			Gui.drawScaledCustomSizeModalRect(this.x, this.y, 187 + (i * 26), 178, 26, 26, 13, 13, 256, 256);
			
			this.mouseDragged(mc, mouseX, mouseY);
			
    	}
	}
	
	@Override
	public boolean mousePressed(Minecraft mc, int mouseX, int mouseY) {
        return this.enabled && this.visible && this.hovered;
    }
}
