package tae.cosmetics.gui.util.packet;

import java.awt.Color;
import java.util.Arrays;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.network.Packet;
import net.minecraft.util.ResourceLocation;
import tae.cosmetics.gui.GuiVisualizePackets;

public abstract class AbstractPacketModule extends Gui {
	
	public static final int modwidth = 210;
	public static final int modheightminimized= 20;
	public static final int modheightfull = (modheightminimized + GuiVisualizePackets.spacing) * 5;
	public static final int modtimestampwidth = 100;
		
	//x coord
	public int x = 0;
	//y coord
	public int y = 0;
	//timestamp
	private long timestamp = -1;
	//TODO: make private
	public Packet<?> packet;
	
	protected boolean minimized = true;
	
	protected FontRenderer fontRenderer = Minecraft.getMinecraft().fontRenderer;
		
	private String hoverText;
	
	protected AbstractPacketModule(String info, long timestamp, Packet<?> packet) {
		hoverText = info;
		this.timestamp = timestamp;
		this.packet = packet;
	}
	
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		
		GlStateManager.scale(0.5, 0.5, 0.5);
		
		int color;
		this.drawGradientRect(x - 2, y - 2, x + modtimestampwidth + modwidth * 2 + 2, y + (minimized ? modheightminimized : modheightfull) + 2, color = new Color(128, 0, 128).getRGB(), color);
		this.drawGradientRect(x - 1, y - 1, x + modtimestampwidth + modwidth * 2 + 1, y + (minimized ? modheightminimized : modheightfull) + 1, color = new Color(64, 0, 64).getRGB(), color);
		this.drawGradientRect(x, y, x + modtimestampwidth - 1, y + (minimized ? modheightminimized : modheightfull), color = Color.BLACK.getRGB(), color);
		this.drawGradientRect(x + modtimestampwidth + 1, y, x + modtimestampwidth + modwidth - 1, y + (minimized ? modheightminimized : modheightfull), color = Color.BLACK.getRGB(), color);
		this.drawGradientRect(x + modtimestampwidth + modwidth + 1, y, x + modtimestampwidth + modwidth * 2, y + (minimized ? modheightminimized : modheightfull), color = Color.BLACK.getRGB(), color);
		
		fontRenderer.drawString(Long.toString(getTimestamp()), x + 3, y + 6, Color.WHITE.getRGB());
		drawText(x + 10 + (type() ? modtimestampwidth : modtimestampwidth + modwidth), y + 6);
		GlStateManager.scale(2, 2, 2);
		
	}

	/**
	 * 
	 * Draw text
	 * 
	 * @param x xcoord
	 * @param y ycoord
	 */
	public abstract void drawText(int x, int y);
	
	public String getTip() {
		return hoverText;
	}
	
	public boolean isMinimized() {
		return minimized;
	}
	
	public void setMinimized(boolean bool) {
		minimized = bool;
	}
	
	/**
	 * 
	 * @return unix timestamp of send/recieve packet
	 */
	public long getTimestamp() {
		return timestamp;
	}
	
	/**
	 * 
	 * @return type of packet: true for client, false for server
	 */
	public abstract boolean type();
	
	/**
	 * 
	 * @return when the mouse is overing over the module
	 */
	public boolean isHovered(int mouseX, int mouseY) {
		
		return mouseX > x / 2 && mouseX < (x + modtimestampwidth + modwidth * 2) / 2 && mouseY > y / 2 && mouseY < (y + (minimized ? modheightminimized : modheightfull)) / 2;
		
	}
	
}
