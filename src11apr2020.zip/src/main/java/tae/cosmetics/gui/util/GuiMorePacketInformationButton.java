package tae.cosmetics.gui.util;

import java.awt.Color;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.network.Packet;
import tae.cosmetics.gui.util.packet.GuiGenericPacketInformation;

public class GuiMorePacketInformationButton extends GuiButton {
	
	private Packet<?> packet;
	
	public GuiMorePacketInformationButton(int buttonId, int x, int y, Packet<?> packet) {
		super(buttonId, x, y, 20, 20, "");
		this.packet = packet;
	}
	
	@Override
	public void drawButton(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
        if (this.visible) {
    		GlStateManager.scale(0.5, 0.5, 0.5);
        	
        	//FontRenderer fontrenderer = mc.fontRenderer;
            this.hovered = mouseX >= this.x / 2 && mouseY >= this.y / 2 && mouseX < (this.x + this.width) / 2 && mouseY < (this.y + this.height) / 2;
            int i = this.getHoverState(this.hovered);
           
            Gui.drawRect(x, y, x + width, y + height, Color.BLACK.getRGB());
            
      
            for(int index = 0; index < 5; index++) {

            	Gui.drawRect(x + width / 2 - index, y + 2, x + width / 2 - index + 1, y + height - 2, i == 2 ? Color.YELLOW.getRGB() : Color.WHITE.getRGB());
            	Gui.drawRect(x + width / 2 + index, y + 2, x + width / 2 + index + 1, y + height - 2, i == 2 ? Color.YELLOW.getRGB() : Color.WHITE.getRGB());
            	
            	Gui.drawRect(x + 2, y + height / 2 - index, x + width - 2, y + height / 2 - index + 1, i == 2 ? Color.YELLOW.getRGB() : Color.WHITE.getRGB());
            	Gui.drawRect(x + 2, y + height / 2 + index, x + width - 2, y + height / 2 + index + 1, i == 2 ? Color.YELLOW.getRGB() : Color.WHITE.getRGB());
            	
            }
            	
            
    		GlStateManager.scale(2, 2, 2);
            
        }
    }

	@Override
	public boolean mousePressed(Minecraft mc, int mouseX, int mouseY) {
		return this.enabled && this.visible && this.hovered;
    }
	
	public void openScreen(GuiScreen parent) {
		
		Minecraft.getMinecraft().addScheduledTask(() -> {
			
			Minecraft.getMinecraft().displayGuiScreen(new GuiGenericPacketInformation(packet, parent));
			
		});
		
	}
	
}
