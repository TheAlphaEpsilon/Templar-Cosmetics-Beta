package tae.cosmetics.gui;

import java.io.IOException;

import org.lwjgl.input.Mouse;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import tae.cosmetics.gui.util.mainscreen.CancelPacketsGuiList;
import tae.cosmetics.gui.util.mainscreen.VisualizePacketsGuiList;
import tae.cosmetics.mods.CancelPacketMod;
import tae.cosmetics.mods.VisualizePacketsMod;

public class GuiMoveScreenElements extends GuiScreen {
	
	private CancelPacketsGuiList cancel;
	private VisualizePacketsGuiList caught;
	
	private boolean mouseWasClicked = false;
	
	private int oldCancelX = 0;
	private int oldCancelY = 0;
	
	private int oldCaughtX = 0;
	private int oldCaughtY = 0;
	
	private int oldMouseX = 0;
	private int oldMouseY = 0;
	
	public GuiMoveScreenElements() {
		
		cancel = CancelPacketMod.getGuiTitleCopy();
		caught = VisualizePacketsMod.getGuiTitleCopy();
		
	}
	
	@Override
	public void onGuiClosed() {
		
		CancelPacketMod.updateGui(cancel.x, cancel.y);
		VisualizePacketsMod.updateGui(caught.x, caught.y);
		
	}
	
	@Override
	public void initGui() {
		
	}
	
	@Override
	protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
		
		super.mouseClicked(mouseX, mouseY, mouseButton);
		
	}
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		
		this.drawDefaultBackground();
		
		boolean clickflag = Mouse.isButtonDown(0);
		
		if(!mouseWasClicked && clickflag) {
			oldCancelX = cancel.x;
			oldCancelY = cancel.y;
			
			oldCaughtX = caught.x;
			oldCaughtY = caught.y;
			
			oldMouseX = mouseX;
			oldMouseY = mouseY;
		}
		
		if(clickflag && mouseWasClicked) {
			
			if(cancel.isHovered(mouseX, mouseY)) {
				
				cancel.x = oldCancelX + (mouseX - oldMouseX);
				cancel.y = oldCancelY + (mouseY - oldMouseY);
				
			} else if(caught.isHovered(mouseX, mouseY)) {
				
				caught.x = oldCaughtX + mouseX - oldMouseX;
				caught.y = oldCaughtY + mouseY - oldMouseY;
				
			}
			
		}
		
		mouseWasClicked = clickflag;
		
		cancel.draw(mouseX, mouseY);
		caught.draw(mouseX, mouseY);
	}
			
	@Override
	public boolean doesGuiPauseGame() {
	    return false;
	}
}
