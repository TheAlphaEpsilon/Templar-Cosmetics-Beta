package tae.cosmetics.util;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLHandshakeException;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import tae.cosmetics.Globals;
import tae.cosmetics.exceptions.TAEModException;

public class API2b2tdev implements Globals {
	
	private static int priosize = -1;
	
	public static int getPrioSize() {
		return priosize;
	}
	
	public static void update() {
				
		//Cuz server doesn't wanna place nice with normal https streams
		//I have no idea what I'm doing
		
		try {
			SSLContext sslcontext = SSLContext.getInstance("TLSv1.2");
			sslcontext.init(null, null, null);
		    SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslcontext,
		        SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER); // Socket
		    HttpClient client =
		        HttpClients.custom().setSSLSocketFactory(socketFactory).build();
		    HttpGet httpget = new HttpGet(prioqueue);
		    HttpResponse response = client.execute(httpget);
		    
		    String data = EntityUtils.toString(response.getEntity());
		    
		    priosize = Integer.parseInt(data.split(",")[1]);
		    
		} catch (Exception e) {
		    new TAEModException(e.getClass(), e.getMessage()).post();
		}
		
	}
	
}
