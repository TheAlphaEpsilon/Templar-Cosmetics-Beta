package tae.cosmetics.util;

import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

import org.apache.commons.io.IOUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import tae.cosmetics.Globals;
import tae.cosmetics.exceptions.TAEModException;

public class RebaneGetter implements Globals{
	
	private static JSONObject json = null;
	
	private static ArrayList<String> nameArray = new ArrayList<String>();
	
	private static int size = -1;
	
	public static void init() {
		getBaseJSON();
		nameArray = getNameArray();
		size = getAmount();		
	}
	
	public static int getSize() {
		return size;
	}
	
	private static void getBaseJSON() {
		try {
			String rawjson = getDataFromURL(rebaneQueue);
			JSONParser parser = new JSONParser();
			json = (JSONObject) parser.parse(rawjson);
		} catch (Exception e) {
			new TAEModException(RebaneGetter.class, e.getMessage()).post();
		}
	}
	
	private static ArrayList<String> getNameArray() {
		if(json == null) return null;
		ArrayList<String> names = new ArrayList<String>();
		JSONArray namejson = (JSONArray) json.get("players");
		int jsonsize = namejson.size();
		for(int i = 0; i < jsonsize; i++) {
			String name = (String) ((JSONObject)namejson.get(i)).get("name");
			names.add(name);
		}
		return names;
	}
	
	private static int getAmount() {
		if(json == null) return -1;
		try {
			return Integer.parseInt((String) json.get("queuepos"));
		} catch (Exception e) {
			return -1;
		}
	}
	
	public static ArrayList<String> getNames() {
		if(nameArray == null) {
			return new ArrayList<String>();
		}
		return new ArrayList<String>(nameArray);
	}
	
	public static boolean hasJSON() {
		return json!=null;
	}
	
	private static String getDataFromURL(String url) {
		try {
			return IOUtils.toString(new URL(url), Charset.defaultCharset());
		} catch (Exception e) {
			return null;
		}
	}
	
}
