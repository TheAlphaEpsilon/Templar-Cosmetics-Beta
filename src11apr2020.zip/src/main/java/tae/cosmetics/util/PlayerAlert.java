package tae.cosmetics.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import net.minecraft.util.text.TextComponentString;
import tae.cosmetics.Globals;

public class PlayerAlert implements Globals{
	
	private static HashMap<String, PlayerData> playeruuidmap = new HashMap<String, PlayerData>();
	
	public static HashMap<String, String> getUUIDPlayerName() {
		HashMap<String, String> toReturn = new HashMap<String, String>();
		for(String uuid : playeruuidmap.keySet()) {
			toReturn.put(uuid, playeruuidmap.get(uuid).oldname);
		}
		return toReturn;
	}
	
	public static HashMap<String, PlayerData> dataCopy() {
		return new HashMap<String, PlayerData>(playeruuidmap);
	}
	
	public static Set<String> getOrderedNames() {
		TreeSet<String> toReturn = new TreeSet<String>();
		for(String uuid : playeruuidmap.keySet()) {
			toReturn.add(playeruuidmap.get(uuid).oldname);
		}
		return toReturn;
	}
	
	public static boolean alertExists(String name) {
		String[] data = MojangGetter.getInfoFromName(name);
		if(data == null) return false;
		return playeruuidmap.containsKey(data[0]);
	}
	
	public static String addName(String name) {
		if(alertExists(name)) return null;
		String[] data = MojangGetter.getInfoFromName(name);
		if(data == null) return null;
		playeruuidmap.put(data[0], new PlayerData(data[0], data[1]));
		return data[1];
	}
	
	public static boolean removeName(String name) {
		String[] data = MojangGetter.getInfoFromName(name);
		if(data == null) return false;
		String playeruuid = data[0];
		if(playeruuidmap.remove(playeruuid) == null) {
			return false;
		} 
		return true;
	}
	
	public static void removeUUID(String uuid) {
		playeruuidmap.remove(uuid);
	}
	
	
	public static void addFromConfig(String uuid, String name, String prefix, boolean alert, boolean queue, boolean assumePrio) {
		playeruuidmap.put(uuid, new PlayerData(uuid, name, prefix, alert, queue, assumePrio));
	}
	
	public static String getMessage(String uuid) {
		if(playeruuidmap.get(uuid) == null) return null;
		String setname = playeruuidmap.get(uuid).oldname;
		String realname = MojangGetter.getCurrentNameFromUUID(uuid);
		if(realname == null || setname.equals(realname)) {
			return "Player " + setname + " has %s";
		} else {
			return "Player " + realname + " has %s. Previously " + setname;
		}
	}
	
	public static String getNameFromMap(String uuid) {
		return playeruuidmap.get(uuid).oldname;
	}
	
	public static List<String> getOrderedUUIDFromName() {
		List<String> uuids = new ArrayList<String>(playeruuidmap.keySet());
		Collections.sort(uuids, new Comparator<String>() {

			@Override
			public int compare(String o1, String o2) {
				return playeruuidmap.get(o1).oldname.toLowerCase().compareTo(playeruuidmap.get(o2).oldname.toLowerCase());
			}

			
		});
		
		return uuids;
	}
	
	public static void updateQueuePositions() {
		ArrayList<String> nameArray = RebaneGetter.getNames();
		for(String uuid : PlayerAlert.getOrderedUUIDFromName()) {
		
			String name = PlayerAlert.getNameFromMap(uuid);
			//name is in queue cache
			if(nameArray.contains(name)) {
				
				//player isnt online
				PlayerData player;
				if(!((player = playeruuidmap.get(uuid)).inGame)) {
					
					//set queue pos
					int currentQueuePos = nameArray.indexOf(name) + 1;
					
					if(player.totalQueueOnJoin < 0 || player.queuePos < 1) {
						player.totalQueueOnJoin = RebaneGetter.getSize();
					}
					
					if(player.prioQueueOnJoin < 0|| player.queuePos < 1) {
						player.prioQueueOnJoin = API2b2tdev.getPrioSize();
					}
					
					if(player.assumePrio && player.totalQueueOnJoin > 0 && player.prioQueueOnJoin > 0) {
						
						int toTest = player.prioQueueOnJoin - (player.totalQueueOnJoin - currentQueuePos);
						
						player.queuePos = toTest;//(toTest < 1) ? currentQueuePos : toTest;
						
					} else {
						
						player.queuePos = currentQueuePos;
						
					}
					
					//Once on in q
					if(player.queue && !player.sentInQueue) {
						
						player.sentInQueue = true;
						
						player.sentLeftQueue = false;
						
						player.wasInQueue = true;
						
						String toSend = colorcode+"6Player " + playeruuidmap.get(uuid).oldname + " is in queue "+colorcode+"l[" + player.queuePos +"]"; //" + player.totalQueueOnJoin + " " + player.prioQueueOnJoin;
						if(mc.player != null) {
							mc.player.sendMessage(new TextComponentString(toSend));
						}
						
					}
					
				//player is online	
				} else {
					
					if(player.queuePos > 0) {
						int posPast = player.totalQueueOnJoin - player.queuePos;
						
						//TODO: get prio to normal ratio
						
					}
										
					if(!player.sentLeftQueue && player.wasInQueue) {
						
						player.wasInQueue = false;
						
						player.sentLeftQueue = true;
						
						String toSend = colorcode+"6Player " + playeruuidmap.get(uuid).oldname + " has left the queue." + player.queuePos;
						if(mc.player != null && player.queue && !(player.inGame && player.alert)) {
							mc.player.sendMessage(new TextComponentString(toSend));
						}
						
					}
					
					player.queuePos = -1;
					
				}
					
			//name isnt in queue		
			} else {
				
				PlayerData player = playeruuidmap.get(uuid);
				
				if(player.queuePos > 0) {
					int posPast = player.totalQueueOnJoin - player.queuePos;
				
					//TODO: get prio to normal ratio
					
				}
								
				player.sentInQueue = false;
				
				if(!player.sentLeftQueue && player.wasInQueue) {
					
					player.wasInQueue = false;
					
					player.sentLeftQueue = true;
					
					String toSend = colorcode+"6Player " + playeruuidmap.get(uuid).oldname + " has left the queue." + player.queuePos;
					if(mc.player != null && player.queue && !(player.inGame && player.alert)) {
						mc.player.sendMessage(new TextComponentString(toSend));
					}
					
				}
				
				player.queuePos = -1;
				
			}
			
		}
	}
	
	public static void toggleAllAlerts(boolean bool) {
		for(String uuid : playeruuidmap.keySet()) {
			playeruuidmap.get(uuid).alert = bool;
		}
	}
	
	public static void toggleAllQueue(boolean bool) {
		for(String uuid : playeruuidmap.keySet()) {
			playeruuidmap.get(uuid).queue = bool;
		}
	}
	
	public static void updateSendAlert(String uuid, boolean bool) {
		playeruuidmap.get(uuid).alert = bool;
	}
	
	public static void updateQueueSendAlert(String uuid, boolean bool) {
		playeruuidmap.get(uuid).queue = bool;
	}
	
	public static void updatePrefix(String uuid, String prefix) {
		playeruuidmap.get(uuid).chatPrefix = prefix;
	}
	
	public static void updateName(String uuid, String newname) {
		playeruuidmap.get(uuid).oldname = newname;
	}
	
	public static void toggleOnline(String uuid, boolean bool) {
		playeruuidmap.get(uuid).inGame = bool;
	}
	
	public static void updateQueuePos(String uuid, int indexOf) {
		playeruuidmap.get(uuid).queuePos = indexOf;
	}
	
	public static void updateAssumePrio(String uuid, boolean state) {
		playeruuidmap.get(uuid).assumePrio = state;
	}
	
	
	static public class PlayerData {
		
		private String uuid;
		private String oldname;
		private String newname;
		private String chatPrefix;
		private boolean inGame;
		private boolean alert;
		private boolean queue;
		private boolean sentInQueue;
		private boolean sentLeftQueue;
		private boolean wasInQueue;
		private boolean assumePrio;
		private int queuePos;
		private int totalQueueOnJoin;
		private int prioQueueOnJoin;
		
		private PlayerData(String uuid, String oldname) {
			this(uuid, oldname, "", true, true, false);
		}
		
		private PlayerData(String uuid, String oldname, String prefix, boolean alert, boolean queue, boolean assumePrio) {
			this.oldname = oldname;
			this.uuid = uuid;
			chatPrefix = prefix;
			newname = MojangGetter.getCurrentNameFromUUID(uuid);
			inGame = false;
			sentInQueue = false;
			sentLeftQueue = false;
			wasInQueue = false;
			queuePos = -1;
			totalQueueOnJoin = -1;
			prioQueueOnJoin = -1;
			this.alert = alert;
			this.queue = queue;
			this.assumePrio = assumePrio;
		}
		
		public boolean needNameUpdate() {
			if(newname == null) return false;
			return !oldname.equals(newname);
		}
		
		public String getOldName() {
			return oldname;
		}
		
		public String getNewName() {
			return newname;
		}
		
		public String getUUID() {
			return uuid;
		}
		
		public String getChatPrefix() {
			return chatPrefix;
		}
		
		public boolean getInGame() {
			return inGame;
		}
		
		public boolean getSendAlert() {
			return alert;
		}
		
		public boolean getSendQueueAlert() {
			return queue;
		}
		
		public boolean getAssumePrio() {
			return assumePrio;
		}
		
		public int queuePos() {
			return queuePos;
		}
		
	}

}