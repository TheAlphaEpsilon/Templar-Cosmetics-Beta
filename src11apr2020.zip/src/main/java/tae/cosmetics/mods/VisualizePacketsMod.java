package tae.cosmetics.mods;

import java.time.Instant;

import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent.ClientDisconnectionFromServerEvent;
import tae.cosmetics.gui.GuiVisualizePackets;
import tae.cosmetics.gui.util.mainscreen.VisualizePacketsGuiList;
import tae.packetevent.PacketEvent;

public class VisualizePacketsMod extends BaseMod {

	private static boolean enabled = false;
	
	private static VisualizePacketsGuiList gui = new VisualizePacketsGuiList("Caught Packet:", 100, 50);
	
	public static void forceStop() {
		enabled = false;
	}
	
	public static void toggle() {
		enabled = enabled ? false : true;
		if(enabled) {
			GuiVisualizePackets.instance().reset();
			gui.reset();
		}
	}
	
	public static VisualizePacketsGuiList getGuiTitleCopy() {
		return new VisualizePacketsGuiList(gui.getTitle(), gui.x, gui.y);
	}
	
	public static void updateGui(int x, int y) {
		gui.x = x;
		gui.y = y;
	}
	
	@SubscribeEvent
	public void onDisconnect(ClientDisconnectionFromServerEvent event) {
		enabled = false;
	}
	
	@SubscribeEvent (priority = EventPriority.LOWEST)
	public void onSendPacket(PacketEvent.Outgoing event) {
		
		if(enabled && !event.isCanceled()) {
			gui.addPacket(event.getPacket());
			GuiVisualizePackets.instance().addClientPacket(event.getPacket(), Instant.now().toEpochMilli());
		}
		
	}
	
	@SubscribeEvent (priority = EventPriority.LOWEST)
	public void onSendPacket(PacketEvent.Incoming event) {
		
		if(enabled && !event.isCanceled()) {
			gui.addPacket(event.getPacket());
			GuiVisualizePackets.instance().addServerPacket(event.getPacket(), Instant.now().toEpochMilli());
		}
		
	}
	
	@SubscribeEvent
	public void onDrawGameScreen(RenderGameOverlayEvent event) {
		
		if(!enabled || event.getType() != ElementType.TEXT) {
			return;
		}
		
		gui.draw(-1, -1);
	
	}
}
